from . import msgbox

setup = msgbox.setup
