### I am submitting a...
```
 [ ] Bug fix
 [ ] Feature addition or improvement for an existing cog
```

### Name of the cog in question:


### Description of my bug fix/improvement:

