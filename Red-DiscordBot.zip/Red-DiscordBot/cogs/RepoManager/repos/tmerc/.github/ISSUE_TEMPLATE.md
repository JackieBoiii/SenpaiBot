### I am submitting a...
```
 [ ] Bug report
 [ ] Feature request or improvement for an existing cog
```

### Name of the cog in question:


### Description of my issue/request:


### If it's a bug, steps to reproduce:
 
 1.


### If it's a bug, a stack trace:
```
Paste it here.
```
