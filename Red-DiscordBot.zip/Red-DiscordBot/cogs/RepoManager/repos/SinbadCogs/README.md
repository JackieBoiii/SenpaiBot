# SinbadCogs
[![Build Status](https://travis-ci.org/mikeshardmind/SinbadCogs.svg?branch=v3)](https://travis-ci.org/mikeshardmind/SinbadCogs) 
[![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/ambv/black) 
[![Red](https://img.shields.io/badge/Red-DiscordBot-red.svg)](https://github.com/Cog-Creators/Red-DiscordBot/tree/V3/develop) 
[![Tip Jar](https://img.shields.io/badge/Paypal-Donate-blue.svg)](https://www.paypal.me/mikeshardmind)

## Whats here?

Various addons for Red Discordbot. Most of these are focused around utility purposes.

I'll have a more in depth guide to my cogs put together at a later date.

## Contact

I'm Sinbad on Discord

Feel free to ask for help with these in [This Discord](https://discord.gg/mb85deu)

I'm also around in the main [Red Discord Server](https://discord.gg/red)


If you'd like to see additional features or find a bug, leave an issue
or make a pull request

## So you want to support this?

The best way you can help support this is to give me feedback on bugs
issues and feature requests [here](https://github.com/mikeshardmind/SinbadCogs/issues)

If you feel like contributing more directly, PRs are welcome.

I have a [patreon](https://www.patreon.com/mikeshardmind) or [paypal](https://www.paypal.me/mikeshardmind)
if you feel like paying for a drink or two instead

