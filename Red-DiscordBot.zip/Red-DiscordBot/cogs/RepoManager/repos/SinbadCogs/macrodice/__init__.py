from . import core

setup = core.setup
