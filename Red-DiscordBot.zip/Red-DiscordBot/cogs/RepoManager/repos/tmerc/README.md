# tmerc-cogs

The V3 versions of my cogs are a work-in-progress. Everything here should be considered unstable and is subject to change with zero notice, so use these cogs at your own risk.

More documentation will come as the cogs are finalized.
